$(".button-collapse").sideNav();
$('ul.tabs').tabs();